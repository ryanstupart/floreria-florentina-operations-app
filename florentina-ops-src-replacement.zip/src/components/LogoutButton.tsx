"use client";

import { createClient } from "../lib/supabase/client";
import { useRouter } from "next/navigation";

export default function LogoutButton() {
  const router = useRouter();
  const supabase = createClient();

  async function handleLogout() {
    await supabase.auth.signOut();
    router.push("/login");
    router.refresh();
  }

  return (
    <button
      onClick={handleLogout}
      className="rounded-full border border-[#ead8cc] bg-white px-4 py-2 text-sm font-semibold text-[#6f3b2a] shadow-sm transition hover:bg-[#fbf5ef]"
    >
      Log out
    </button>
  );
}
