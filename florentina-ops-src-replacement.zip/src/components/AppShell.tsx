import Link from "next/link";
import LogoutButton from "./LogoutButton";

type AppShellProps = {
  children: React.ReactNode;
  title: string;
  subtitle?: string;
};

const navItems = [
  { href: "/dashboard", label: "Dashboard", icon: "✦" },
  { href: "/orders", label: "Orders", icon: "❀" },
  { href: "/employees", label: "Employees", icon: "☻" },
  { href: "/schedule", label: "Employee Schedule", icon: "◷" },
  { href: "/customer-messages", label: "Customer Messages", icon: "✉" },
  { href: "/team-chat", label: "Team Chat", icon: "◆" },
];

export default function AppShell({ children, title, subtitle }: AppShellProps) {
  return (
    <main className="min-h-screen bg-[#f8f1ea] text-[#2a1d18]">
      <header className="border-b border-[#ecd9cc] bg-white/90 px-5 py-4 backdrop-blur">
        <div className="mx-auto flex max-w-7xl items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="flex h-11 w-11 items-center justify-center rounded-2xl bg-[#7a3f2a] text-lg font-bold text-white shadow-sm">
              FF
            </div>
            <div>
              <h1 className="text-xl font-bold tracking-tight text-[#5b2e1f]">
                Florentina Ops
              </h1>
              <p className="text-sm text-[#7b665c]">Operations control layer</p>
            </div>
          </div>
          <LogoutButton />
        </div>
      </header>

      <div className="mx-auto grid max-w-7xl gap-6 px-5 py-6 md:grid-cols-[260px_1fr]">
        <aside className="h-fit rounded-3xl border border-[#ead8cc] bg-white p-4 shadow-sm">
          <div className="mb-4 rounded-2xl bg-[#fbf5ef] p-4">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#9b6b59]">
              MVP Workspace
            </p>
            <p className="mt-1 text-sm text-[#6c5750]">
              Orders, schedules, chat, and payment tracking foundation.
            </p>
          </div>
          <nav className="space-y-1 text-sm font-semibold text-[#523426]">
            {navItems.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className="flex items-center gap-3 rounded-2xl px-3 py-2.5 transition hover:bg-[#f8f1ea] hover:text-[#7a3f2a]"
              >
                <span className="flex h-7 w-7 items-center justify-center rounded-xl bg-[#fbf5ef] text-[#7a3f2a]">
                  {item.icon}
                </span>
                {item.label}
              </Link>
            ))}
          </nav>
        </aside>

        <section>
          <div className="mb-6 rounded-3xl border border-[#ead8cc] bg-white p-6 shadow-sm">
            <p className="text-xs font-bold uppercase tracking-[0.22em] text-[#9b6b59]">
              Floreria Florentina
            </p>
            <h2 className="mt-2 text-3xl font-bold tracking-tight text-[#3a241a]">
              {title}
            </h2>
            {subtitle && <p className="mt-2 max-w-3xl text-[#6c5750]">{subtitle}</p>}
          </div>

          {children}
        </section>
      </div>
    </main>
  );
}
