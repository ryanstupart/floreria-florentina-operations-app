import { redirect } from "next/navigation";
import { createClient } from "../../lib/supabase/server";
import AppShell from "../../components/AppShell";

export default async function DashboardPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name, role")
    .eq("id", user.id)
    .single();

  const { count: orderCount } = await supabase.from("orders").select("*", { count: "exact", head: true });
  const { count: messageCount } = await supabase.from("customer_messages").select("*", { count: "exact", head: true });
  const { count: shiftCount } = await supabase.from("employee_shifts").select("*", { count: "exact", head: true });

  return (
    <AppShell
      title="Operations Dashboard"
      subtitle={`Welcome, ${profile?.full_name ?? user.email} • Role: ${profile?.role ?? "unknown"}`}
    >
      <div className="grid gap-4 md:grid-cols-3">
        <Metric title="Orders Tracked" value={orderCount ?? 0} note="Manual + future integrations" />
        <Metric title="Customer Messages" value={messageCount ?? 0} note="Website chat inbox" />
        <Metric title="Employee Shifts" value={shiftCount ?? 0} note="Separate staff schedule" />
      </div>

      <div className="mt-6 grid gap-4 lg:grid-cols-[1fr_360px]">
        <div className="rounded-3xl border border-[#ead8cc] bg-white p-6 shadow-sm">
          <h3 className="text-lg font-bold text-[#3a241a]">MVP Roadmap</h3>
          <div className="mt-4 space-y-3">
            {["Foundation + auth", "Employees table", "Manual orders", "Order calendar", "Employee schedule", "Website chat inbox", "Square/Squarespace integrations later"].map((item, index) => (
              <div key={item} className="flex items-center gap-3 rounded-2xl bg-[#fbf5ef] p-3">
                <span className="flex h-8 w-8 items-center justify-center rounded-full bg-white text-sm font-bold text-[#7a3f2a]">{index + 1}</span>
                <span className="font-medium text-[#563a2d]">{item}</span>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-3xl border border-[#ead8cc] bg-[#7a3f2a] p-6 text-white shadow-sm">
          <p className="text-sm font-bold uppercase tracking-[0.2em] text-[#f0d7ca]">Access Rule</p>
          <h3 className="mt-3 text-2xl font-bold">Owner/Admin only</h3>
          <p className="mt-3 text-sm leading-relaxed text-[#f9e8df]">
            Current testing access is limited to Yajaira and Robert. Public signup is intentionally not part of the MVP.
          </p>
        </div>
      </div>
    </AppShell>
  );
}

function Metric({ title, value, note }: { title: string; value: number; note: string }) {
  return (
    <div className="rounded-3xl border border-[#ead8cc] bg-white p-6 shadow-sm">
      <p className="text-sm font-semibold text-[#7b665c]">{title}</p>
      <p className="mt-2 text-4xl font-bold text-[#3a241a]">{value}</p>
      <p className="mt-2 text-sm text-[#8a766e]">{note}</p>
    </div>
  );
}
