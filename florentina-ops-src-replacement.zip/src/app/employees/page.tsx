import AppShell from "../../components/AppShell";

const employees = [
  { name: "Yajaira", role: "Owner", status: "Active", access: "Full access" },
  { name: "Robert", role: "Admin", status: "Active", access: "Admin access" },
  { name: "Future Staff", role: "Staff", status: "Not provisioned", access: "Later phase" },
];

export default function EmployeesPage() {
  return (
    <AppShell title="Employees" subtitle="Manage staff records and future account provisioning.">
      <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
        <div className="rounded-3xl border border-[#ead8cc] bg-white p-6 shadow-sm">
          <h3 className="text-lg font-bold text-[#3a241a]">Team Directory</h3>
          <div className="mt-4 space-y-3">
            {employees.map((employee) => (
              <div key={employee.name} className="flex items-center justify-between rounded-2xl bg-[#fbf5ef] p-4">
                <div>
                  <p className="font-bold text-[#3a241a]">{employee.name}</p>
                  <p className="text-sm text-[#7b665c]">{employee.role} • {employee.access}</p>
                </div>
                <span className="rounded-full bg-white px-3 py-1 text-xs font-bold text-[#7a3f2a]">{employee.status}</span>
              </div>
            ))}
          </div>
        </div>
        <div className="rounded-3xl border border-[#ead8cc] bg-white p-6 shadow-sm">
          <h3 className="text-lg font-bold text-[#3a241a]">Provisioning Rule</h3>
          <p className="mt-3 text-sm leading-relaxed text-[#6c5750]">
            For MVP testing, only Yajaira and Robert should have app accounts. Employee account creation should be restricted to Owner/Admin users only.
          </p>
        </div>
      </div>
    </AppShell>
  );
}
