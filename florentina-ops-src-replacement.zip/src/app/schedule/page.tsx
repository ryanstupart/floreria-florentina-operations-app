import AppShell from "../../components/AppShell";

const shifts = [
  { day: "Monday", worker: "Yajaira", time: "9:00 AM - 3:00 PM", note: "Order prep/admin" },
  { day: "Tuesday", worker: "Robert", time: "12:00 PM - 6:00 PM", note: "Operations support" },
  { day: "Wednesday", worker: "TBD", time: "10:00 AM - 4:00 PM", note: "Future staff shift" },
];

export default function SchedulePage() {
  return (
    <AppShell title="Employee Schedule" subtitle="Separate staff scheduling from customer order scheduling.">
      <div className="rounded-3xl border border-[#ead8cc] bg-white p-6 shadow-sm">
        <div className="grid gap-4 md:grid-cols-3">
          {shifts.map((shift) => (
            <div key={shift.day} className="rounded-3xl bg-[#fbf5ef] p-5">
              <p className="text-xs font-bold uppercase tracking-[0.18em] text-[#9b6b59]">{shift.day}</p>
              <h3 className="mt-3 text-xl font-bold text-[#3a241a]">{shift.worker}</h3>
              <p className="mt-2 font-semibold text-[#6f3b2a]">{shift.time}</p>
              <p className="mt-2 text-sm text-[#7b665c]">{shift.note}</p>
            </div>
          ))}
        </div>
      </div>
    </AppShell>
  );
}
