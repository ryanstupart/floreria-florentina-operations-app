"use client";

import { useState } from "react";
import { createClient } from "../../lib/supabase/client";
import { useRouter } from "next/navigation";

export default function LoginPage() {
  const router = useRouter();
  const supabase = createClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [loading, setLoading] = useState(false);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    setErrorMessage("");
    setLoading(true);

    const { error } = await supabase.auth.signInWithPassword({ email, password });

    setLoading(false);

    if (error) {
      setErrorMessage(error.message);
      return;
    }

    router.push("/dashboard");
    router.refresh();
  }

  return (
    <main className="min-h-screen bg-[#f8f1ea] px-5 py-10 text-[#2a1d18]">
      <div className="mx-auto grid min-h-[calc(100vh-5rem)] max-w-6xl items-center gap-8 md:grid-cols-[1.1fr_0.9fr]">
        <section className="hidden md:block">
          <div className="rounded-[2rem] border border-[#ead8cc] bg-white p-8 shadow-sm">
            <p className="text-xs font-bold uppercase tracking-[0.24em] text-[#9b6b59]">
              Floreria Florentina
            </p>
            <h1 className="mt-4 text-5xl font-bold leading-tight tracking-tight text-[#4a2c20]">
              Internal operations, beautifully organized.
            </h1>
            <p className="mt-5 max-w-xl text-lg text-[#6c5750]">
              A custom control layer for chats, manual orders, calendars, staff scheduling, and future Square/Squarespace integrations.
            </p>
            <div className="mt-8 grid gap-3 sm:grid-cols-3">
              {["Website chat", "Order calendar", "Team schedule"].map((label) => (
                <div key={label} className="rounded-2xl bg-[#fbf5ef] p-4 text-sm font-semibold text-[#6f3b2a]">
                  {label}
                </div>
              ))}
            </div>
          </div>
        </section>

        <section className="rounded-[2rem] border border-[#ead8cc] bg-white p-7 shadow-sm">
          <div className="mb-8 flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-[#7a3f2a] font-bold text-white">
              FF
            </div>
            <div>
              <h2 className="text-2xl font-bold text-[#5b2e1f]">Florentina Ops</h2>
              <p className="text-sm text-[#7b665c]">Owner/Admin login</p>
            </div>
          </div>

          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="text-sm font-semibold text-[#513629]">Email</label>
              <input
                className="mt-1 w-full rounded-2xl border border-[#ead8cc] bg-[#fffdfb] px-4 py-3 text-gray-900 outline-none transition focus:border-[#7a3f2a]"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>

            <div>
              <label className="text-sm font-semibold text-[#513629]">Password</label>
              <input
                className="mt-1 w-full rounded-2xl border border-[#ead8cc] bg-[#fffdfb] px-4 py-3 text-gray-900 outline-none transition focus:border-[#7a3f2a]"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                required
              />
            </div>

            {errorMessage && (
              <p className="rounded-2xl bg-red-50 p-3 text-sm text-red-700">{errorMessage}</p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="w-full rounded-2xl bg-[#7a3f2a] px-4 py-3 font-bold text-white shadow-sm transition hover:bg-[#633222] disabled:opacity-60"
            >
              {loading ? "Logging in..." : "Log in"}
            </button>
          </form>

          <p className="mt-5 text-xs leading-relaxed text-[#7b665c]">
            MVP access is limited to Yajaira as Owner and Robert as Admin. Employee account provisioning comes later.
          </p>
        </section>
      </div>
    </main>
  );
}
