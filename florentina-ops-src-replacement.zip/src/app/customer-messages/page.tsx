import AppShell from "../../components/AppShell";

const messages = [
  { name: "Lucia", language: "Spanish", message: "¿Tienen arreglos para cumpleaños mañana?", status: "New" },
  { name: "James", language: "English", message: "Can I schedule delivery for Friday afternoon?", status: "Open" },
  { name: "Marisol", language: "Spanish", message: "Quiero un ramo de tulipanes rosados.", status: "Needs reply" },
];

export default function CustomerMessagesPage() {
  return (
    <AppShell title="Customer Messages" subtitle="Website chat inbox for Squarespace customer requests.">
      <div className="space-y-4">
        {messages.map((message) => (
          <div key={message.name} className="rounded-3xl border border-[#ead8cc] bg-white p-5 shadow-sm">
            <div className="flex items-center justify-between gap-3">
              <div>
                <h3 className="font-bold text-[#3a241a]">{message.name}</h3>
                <p className="text-sm text-[#7b665c]">Language: {message.language}</p>
              </div>
              <span className="rounded-full bg-[#fbf5ef] px-3 py-1 text-xs font-bold text-[#7a3f2a]">{message.status}</span>
            </div>
            <p className="mt-4 rounded-2xl bg-[#fbf5ef] p-4 text-[#4b372e]">{message.message}</p>
          </div>
        ))}
      </div>
    </AppShell>
  );
}
