import AppShell from "../../components/AppShell";

const chat = [
  { sender: "Yajaira", message: "Please confirm all pickup times before arranging flowers." },
  { sender: "Robert", message: "Square payment links should be attached to manual orders once integration is added." },
  { sender: "System note", message: "Team chat is internal only and separate from customer website chat." },
];

export default function TeamChatPage() {
  return (
    <AppShell title="Team Chat" subtitle="Internal updates, order notes, and team coordination.">
      <div className="rounded-3xl border border-[#ead8cc] bg-white p-6 shadow-sm">
        <div className="space-y-3">
          {chat.map((item) => (
            <div key={item.sender} className="rounded-3xl bg-[#fbf5ef] p-4">
              <p className="text-sm font-bold text-[#6f3b2a]">{item.sender}</p>
              <p className="mt-1 text-[#4b372e]">{item.message}</p>
            </div>
          ))}
        </div>
        <div className="mt-5 flex gap-2">
          <input className="flex-1 rounded-2xl border border-[#ead8cc] px-4 py-3 outline-none" placeholder="Message input coming next..." disabled />
          <button className="rounded-2xl bg-[#7a3f2a] px-5 py-3 font-bold text-white opacity-70" disabled>Send</button>
        </div>
      </div>
    </AppShell>
  );
}
