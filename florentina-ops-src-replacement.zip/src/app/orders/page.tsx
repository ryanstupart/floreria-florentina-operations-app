import AppShell from "../../components/AppShell";

const mockOrders = [
  { customer: "Maria Lopez", source: "manual", type: "Pickup", date: "May 20", time: "3:00 PM", payment: "Unpaid", status: "New" },
  { customer: "Carlos Rivera", source: "chat", type: "Delivery", date: "May 21", time: "11:30 AM", payment: "Paid", status: "Confirmed" },
  { customer: "Ana Martinez", source: "square", type: "Pickup", date: "May 22", time: "5:00 PM", payment: "Partial", status: "In progress" },
];

export default function OrdersPage() {
  return (
    <AppShell title="Orders" subtitle="Track manual, Square, Squarespace, phone, chat, and in-store orders.">
      <div className="rounded-3xl border border-[#ead8cc] bg-white p-6 shadow-sm">
        <div className="mb-5 flex flex-col justify-between gap-3 sm:flex-row sm:items-center">
          <div>
            <h3 className="text-lg font-bold text-[#3a241a]">Order Calendar Preview</h3>
            <p className="text-sm text-[#7b665c]">Mock data for layout testing. Supabase insert forms come next.</p>
          </div>
          <button className="rounded-2xl bg-[#7a3f2a] px-4 py-2 text-sm font-bold text-white">New Manual Order</button>
        </div>
        <div className="overflow-hidden rounded-2xl border border-[#f0ded2]">
          <table className="w-full min-w-[760px] text-left text-sm">
            <thead className="bg-[#fbf5ef] text-[#6f3b2a]">
              <tr>{["Customer", "Source", "Type", "Date", "Time", "Payment", "Status"].map(h => <th key={h} className="px-4 py-3 font-bold">{h}</th>)}</tr>
            </thead>
            <tbody className="divide-y divide-[#f0ded2]">
              {mockOrders.map((order) => (
                <tr key={order.customer} className="text-[#4b372e]">
                  <td className="px-4 py-4 font-semibold">{order.customer}</td>
                  <td className="px-4 py-4 capitalize">{order.source}</td>
                  <td className="px-4 py-4">{order.type}</td>
                  <td className="px-4 py-4">{order.date}</td>
                  <td className="px-4 py-4">{order.time}</td>
                  <td className="px-4 py-4">{order.payment}</td>
                  <td className="px-4 py-4"><span className="rounded-full bg-[#fbf5ef] px-3 py-1 text-xs font-bold text-[#7a3f2a]">{order.status}</span></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </AppShell>
  );
}
